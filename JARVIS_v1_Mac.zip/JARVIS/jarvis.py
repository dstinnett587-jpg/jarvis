import os
import subprocess
import webbrowser
from datetime import datetime

from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

API_KEY = os.getenv("OPENAI_API_KEY")
MODEL = os.getenv("OPENAI_MODEL", "gpt-5")

SYSTEM_PROMPT = """You are JARVIS, a concise, helpful personal AI assistant.
Speak naturally and professionally, with a calm futuristic assistant style.
Do not claim to have performed computer actions unless the local program actually did them.
"""

client = OpenAI(api_key=API_KEY) if API_KEY else None


def speak(text: str):
    print(f"\nJARVIS: {text}\n")
    try:
        subprocess.run(["say", text], check=False)
    except Exception:
        pass


def open_app(app_name: str):
    aliases = {
        "chrome": "Google Chrome",
        "google chrome": "Google Chrome",
        "safari": "Safari",
        "spotify": "Spotify",
        "terminal": "Terminal",
        "finder": "Finder",
        "calculator": "Calculator",
        "notes": "Notes",
        "messages": "Messages",
        "mail": "Mail",
    }

    app = aliases.get(app_name.lower(), app_name)
    result = subprocess.run(["open", "-a", app], capture_output=True, text=True)

    if result.returncode == 0:
        speak(f"Opening {app}.")
    else:
        speak(f"I couldn't open {app}.")


def handle_local_command(user_text: str):
    lower = user_text.lower().strip()

    if lower in {"quit", "exit", "goodbye"}:
        speak("Goodbye. I'll be here when you need me.")
        return False

    if lower == "help":
        speak("Try: open Chrome, search the web for something, time, say something, or ask me a question.")
        return True

    if lower == "time":
        now = datetime.now().strftime("%I:%M %p")
        speak(f"It is {now}.")
        return True

    if lower.startswith("open "):
        open_app(user_text[5:].strip())
        return True

    if lower.startswith("search "):
        query = user_text[7:].strip()
        webbrowser.open("https://www.google.com/search?q=" + query.replace(" ", "+"))
        speak(f"Searching the web for {query}.")
        return True

    if lower.startswith("say "):
        speak(user_text[4:].strip())
        return True

    return None


def ask_ai(user_text: str):
    if not client:
        speak("My AI brain is not connected yet. Add your OpenAI API key to the .env file.")
        return

    try:
        response = client.responses.create(
            model=MODEL,
            instructions=SYSTEM_PROMPT,
            input=user_text,
        )
        answer = response.output_text.strip()
        speak(answer)
    except Exception as exc:
        print("AI error:", exc)
        speak("I ran into a problem contacting my AI brain. Check your API key and internet connection.")


def main():
    speak("JARVIS online. How may I assist you?")

    while True:
        try:
            user_text = input("YOU: ").strip()
        except (KeyboardInterrupt, EOFError):
            print()
            speak("Goodbye.")
            break

        if not user_text:
            continue

        local_result = handle_local_command(user_text)
        if local_result is False:
            break
        if local_result is True:
            continue

        ask_ai(user_text)


if __name__ == "__main__":
    main()
