# JARVIS v1 — Mac Voice Assistant

This starter project gives you a simple JARVIS-style desktop assistant with:
- typed conversation
- optional OpenAI API integration
- macOS app launching
- web searches
- spoken responses using macOS `say`
- a command structure you can expand later

## Setup

1. Install Python 3.11+ if needed.
2. Open Terminal and `cd` into this folder.
3. Create a virtual environment:
   `python3 -m venv .venv`
4. Activate it:
   `source .venv/bin/activate`
5. Install the dependency:
   `pip install -r requirements.txt`
6. Copy `.env.example` to `.env` and put your OpenAI API key there.
7. Run:
   `python jarvis.py`

The program starts in typed mode. Type `help` for commands.

## Built-in commands

- `open Chrome`
- `open Safari`
- `open Spotify`
- `open Terminal`
- `search <query>`
- `say <text>`
- `time`
- `help`
- `quit`

Voice input is intentionally left as the next upgrade so the starter version is easy to get running and debug.
