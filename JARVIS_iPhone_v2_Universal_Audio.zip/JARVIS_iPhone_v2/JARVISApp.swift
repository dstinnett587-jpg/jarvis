import SwiftUI

@main
struct JARVISApp: App {
    @StateObject private var audioRouter = AudioRouter()
    var body: some Scene {
        WindowGroup {
            ContentView().environmentObject(audioRouter)
        }
    }
}
