import SwiftUI

struct ContentView: View {
    @EnvironmentObject var audioRouter: AudioRouter

    var body: some View {
        NavigationStack {
            VStack(spacing: 24) {
                Text("JARVIS")
                    .font(.system(size: 42, weight: .bold))
                Text("Universal Audio Interface")
                    .foregroundStyle(.secondary)

                VStack(alignment: .leading, spacing: 12) {
                    Label("Output", systemImage: "speaker.wave.2.fill")
                    Text(audioRouter.outputName).font(.headline)
                    Divider()
                    Label("Microphone", systemImage: "mic.fill")
                    Text(audioRouter.inputName).font(.headline)
                }
                .padding()
                .background(.thinMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 18))

                Text(audioRouter.routeDescription)
                    .multilineTextAlignment(.center)

                Text("Connect glasses, AirPods, car audio, or headphones through iOS Bluetooth. JARVIS follows the active audio route.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
            .padding()
            .navigationTitle("JARVIS")
        }
    }
}
