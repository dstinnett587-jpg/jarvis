import Foundation
import AVFoundation
import Combine

final class AudioRouter: ObservableObject {
    @Published private(set) var inputName = "None"
    @Published private(set) var outputName = "None"
    @Published private(set) var routeDescription = "Starting…"

    private let session = AVAudioSession.sharedInstance()
    private var observer: NSObjectProtocol?

    init() {
        observer = NotificationCenter.default.addObserver(
            forName: AVAudioSession.routeChangeNotification,
            object: session,
            queue: .main
        ) { [weak self] _ in self?.refresh() }
        configure()
        refresh()
    }

    deinit {
        if let observer { NotificationCenter.default.removeObserver(observer) }
    }

    private func configure() {
        do {
            try session.setCategory(
                .playAndRecord,
                mode: .voiceChat,
                options: [.allowBluetooth, .allowBluetoothA2DP, .defaultToSpeaker]
            )
            try session.setActive(true)
        } catch {
            routeDescription = "Audio setup error: \(error.localizedDescription)"
        }
    }

    func refresh() {
        let route = session.currentRoute
        inputName = route.inputs.first?.portName ?? "None"
        outputName = route.outputs.first?.portName ?? "None"
        routeDescription = route.outputs.first.map {
            "JARVIS is using: \($0.portName)"
        } ?? "No audio output detected"
    }
}
