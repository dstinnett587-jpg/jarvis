# JARVIS iPhone v2 — Universal Audio Route

JARVIS follows the iPhone's active audio route: WeariQ glasses, AirPods, Bluetooth headsets, car audio, wired headphones, or the iPhone speaker.

iOS limitation: a normal app cannot silently pair/connect arbitrary Bluetooth audio devices. Pair the accessory in iOS Settings first; once connected, JARVIS follows the active route.

## Xcode
1. Create a new iOS App named JARVIS using SwiftUI + Swift.
2. Replace the generated JARVISApp.swift and ContentView.swift with these files.
3. Add AudioRouter.swift to the target.
4. Add microphone permission:
   Privacy - Microphone Usage Description =
   JARVIS needs the microphone so you can talk to your assistant.
5. For background audio, enable Background Modes > Audio, AirPlay, and Picture in Picture.
6. Run on your iPhone.

The next version can add wake word, speech-to-text, OpenAI responses, text-to-speech, camera vision, memory, and commands.
